<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client as TwilioClient;

class TestNotifications extends Command
{
    /**
     * The name and signature of the console command.
     *
     * Usage:
     *  php artisan notif:test --email=test@example.com --whatsapp=+31612345678
     */
    protected $signature = 'notif:test {--email=} {--whatsapp=}';

    /**
     * The console command description.
     */
    protected $description = 'Send a test email (via current mailer) and a test WhatsApp message (via Twilio)';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $email = $this->option('email');
        $whatsapp = $this->option('whatsapp');

        if ($email) {
            $this->sendTestEmail($email);
        } else {
            $this->warn('Skipping email test (no --email provided)');
        }

        if ($whatsapp) {
            $this->sendTestWhatsApp($whatsapp);
        } else {
            $this->warn('Skipping WhatsApp test (no --whatsapp provided)');
        }

        $this->info('Done. Check your Mailpit UI and WhatsApp device.');
        return self::SUCCESS;
    }

    private function sendTestEmail(string $to): void
    {
        $this->info('Sending test email to ' . $to . ' ...');
        try {
            Mail::raw("This is a test email from Villa Upsell. If you see this in Mailpit, SMTP is working.", function ($msg) use ($to) {
                $msg->to($to)->subject('Villa Upsell - Test Email');
            });
            $this->info('Test email dispatched.');
        } catch (\Throwable $e) {
            $this->error('Failed to send test email: ' . $e->getMessage());
            Log::error('notif:test email failed', ['error' => $e->getMessage()]);
        }
    }

    private function sendTestWhatsApp(string $to): void
    {
        $this->info('Sending test WhatsApp to ' . $to . ' ...');
        try {
            $sid = config('services.twilio.sid');
            $token = config('services.twilio.token');
            $from = config('services.twilio.whatsapp_from');

            if (!$sid || !$token || !$from) {
                $this->warn('Twilio not fully configured. Will log the message instead.');
                Log::info('WhatsApp (mock) to ' . $to . ': Test message from Villa Upsell');
                return;
            }

            $fromAddress = str_starts_with($from, 'whatsapp:') ? $from : ('whatsapp:' . ltrim($from, '+'));
            $toAddress = str_starts_with($to, 'whatsapp:') ? $to : ('whatsapp:' . ltrim($to, '+'));

            $client = new TwilioClient($sid, $token);
            $client->messages->create($toAddress, [
                'from' => $fromAddress,
                'body' => 'Villa Upsell - Test WhatsApp message via Twilio Sandbox. If you see this, Twilio is working.',
            ]);

            $this->info('Test WhatsApp sent via Twilio.');
        } catch (\Throwable $e) {
            $this->error('Failed to send test WhatsApp: ' . $e->getMessage());
            Log::error('notif:test whatsapp failed', ['error' => $e->getMessage()]);
        }
    }
}

